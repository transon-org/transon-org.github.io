import pytest

pytest.register_assert_rewrite("transon.tests.base")
